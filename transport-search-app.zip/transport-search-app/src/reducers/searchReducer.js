import * as actionTyps from '../actions/types';
const INITIAL_STATE = {
    searchFilters: [],
    searchResults: [],
}

function SearchReducer(state = INITIAL_STATE, action) {
    switch (action.type) {

        case actionTyps.CLEAR_SEARCH: {
            return {
                ...state,
                searchResults: [],
                searchFilters: []
            }

        }
        case actionTyps.GET_SEARCH_RESULTS: {
            return {
                ...state,
                searchResults: action.payload.results,
                searchFilters: action.payload.filters
            }
        }
        default:
            return state;
    }
}
export { SearchReducer as default, INITIAL_STATE }