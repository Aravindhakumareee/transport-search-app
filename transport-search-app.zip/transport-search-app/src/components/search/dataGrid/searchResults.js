import React, { Component } from 'react';
import DataGrid from '../../common/dataGrid';

class SearchResults extends Component {

    constructor(props) {
        super(props);
        this.state = {
            rows: this.props.searchResult
        }
    }

    componentWillReceiveProps(nextProps){
        this.setState({rows:nextProps.searchResult});
    }

    componentDidMount(){
        this.props.onSearch(null)
    }

    render() {
        const header = ["Bus No", "From", "To"]
        return (<div className="col-md-12">
            <h4>Search results</h4>
            <DataGrid keyID="searchResult"
                colHeader={header}
                dataSource={this.state.rows}
            />
        </div>)
    }

}

export default SearchResults;