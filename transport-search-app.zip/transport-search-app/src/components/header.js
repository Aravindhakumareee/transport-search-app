import React from 'react';

function AppHeader(){
    return (<h1>Transport Application</h1>)
}
export default AppHeader;