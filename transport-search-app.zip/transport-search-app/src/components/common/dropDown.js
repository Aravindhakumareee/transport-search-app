import React, { Component } from 'react';

class CDropDown extends Component {

    constructor(props) {
        super(props);
    }

    renderOptions() {
        return this.props.dataSource && this.props.dataSource.map((item) => {
            return <option key={item.value} value={item.value}>{item.displayText}</option>
        })
    }

    render() {
        return (<div className="form-group">
            <label >{this.props.name}</label>
            <select name={this.props.keyID} key={this.props.keyID} className="form-control">
                {this.renderOptions()}
            </select>
        </div>)
    }

}

export default CDropDown;