import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import AppHeader from './header';
import AdvSearch from './search/adv-search';
import SearchResults from './search/dataGrid/searchResults';

import SearchResultsContainer from '../containers/searchResultsContainer';
import SearchFiltersContainer from '../containers/searchFiltersContainer';

class App extends Component {



  render() {
    return (
      <div className="container-fluid">
        <div className="row justify-content-center">
          <AppHeader />
        </div>
        <div className="row">
          <SearchFiltersContainer />
        </div>
        <div className="row">
          <SearchResultsContainer />
        </div>
      </div>
    );
  }
}

export default App;
