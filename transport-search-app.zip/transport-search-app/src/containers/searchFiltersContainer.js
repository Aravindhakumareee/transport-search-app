import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import {onSearch} from '../actions/searchAction';
import AdvSearch from '../components/search/adv-search';

const mapStateToProps = state => {
    return {
        searchFilters: state.searchReducer.searchFilters,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onSearch: (filterData) => dispatch(onSearch(filterData)),
    }
}

const SearchFiltersContainer = connect(mapStateToProps, mapDispatchToProps)(AdvSearch);
export default SearchFiltersContainer;