import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import SearchResults from '../components/search/dataGrid/searchResults';
import {onSearch} from '../actions/searchAction';


const mapStateToProps = state => {
    return {
        searchResult: state.searchReducer.searchResults,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        onSearch: (filterData) => dispatch(onSearch(filterData)),

    }
}

const SearchResultsContainer = connect(mapStateToProps, mapDispatchToProps)(SearchResults);
export default SearchResultsContainer;