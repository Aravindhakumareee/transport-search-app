import * as actionTypes from './types';
export const onSearch = (filterData) => {
    return (dispatch) => {
        let filterRows = mockData;
        for (var key in filterData) {
            if (filterData[key]) {
                filterRows = filterRows.filter(x => x[key].toLowerCase().includes(filterData[key].toLowerCase()));
            }
        }

        dispatch({
            type: actionTypes.GET_SEARCH_RESULTS,
            payload: { results: filterRows, searchFilters: filterData }
        })
    }
}

const mockData = [
    { busNo: "TN01AB1234", from: "Chennai", to: "Coimbatore" },
    { busNo: "TN01CD5678", from: "Coimbatore", to: "Chennai" },
    { busNo: "TN02CD9012", from: "Theni", to: "Chennai" },
    { busNo: "TN02CD3456", from: "Cuddalore", to: "Chennai" },
    { busNo: "TN02CD7890", to: "Theni", from: "Chennai" },
    { busNo: "TN03CD1234", to: "Cuddalore", from: "Chennai" },
    { busNo: "TN03EF5678", from: "Theni", to: "Coimbatore" },
    { busNo: "TN04EF9012", from: "Cuddalore", to: "Coimbatore" },
    { busNo: "TN04GH3456", to: "Theni", from: "Coimbatore" },
    { busNo: "TN05GH7890", to: "Cuddalore", from: "Coimbatore" },

]